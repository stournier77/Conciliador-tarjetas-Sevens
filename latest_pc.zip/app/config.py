from __future__ import annotations

from pathlib import Path

APP_NAME = "Conciliador de Tarjetas - Maveric"
APP_VERSION = "0.2.1"
APP_DATE = "20-jul-2026"
OUTPUT_FOLDER = "archivos conciliados tarjetas maveric"

_repo_file = Path(__file__).resolve().parents[1] / "github_repo.txt"
_repo_value = _repo_file.read_text(encoding="utf-8").strip() if _repo_file.exists() else "TU_USUARIO/Conciliador-Tarjetas-Maveric"
GITHUB_OWNER, _, GITHUB_REPO = _repo_value.partition("/")
