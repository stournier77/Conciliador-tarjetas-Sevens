#!/bin/zsh
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
RUNTIME="$ROOT/runtime_mac"
UV_DIR="$RUNTIME/uv"
UV_BIN="$UV_DIR/uv"
VENV="$RUNTIME/.venv"
LOG_DIR="$ROOT/logs"
LOG_FILE="$LOG_DIR/ultimo_arranque_mac.log"
mkdir -p "$RUNTIME" "$LOG_DIR"
exec > >(tee -a "$LOG_FILE") 2>&1

echo
echo "================================================"
echo " Conciliador de Tarjetas - Maveric"
echo "================================================"
echo "Inicio: $(date '+%d/%m/%Y %H:%M:%S')"
echo

fail() {
  echo
  echo "ERROR: $1"
  echo "Registro: $LOG_FILE"
  echo
  read "?Presioná Enter para cerrar..."
  exit 1
}

if [[ ! -x "$UV_BIN" ]]; then
  echo "Instalando motor aislado de Python..."
  command -v curl >/dev/null 2>&1 || fail "No se encontró curl."
  curl -LsSf https://astral.sh/uv/install.sh | env UV_INSTALL_DIR="$UV_DIR" sh || fail "No se pudo instalar uv."
fi

"$UV_BIN" python install 3.12 || fail "No se pudo instalar Python 3.12."

if [[ -x "$VENV/bin/python" ]]; then
  CURRENT="$($VENV/bin/python -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")' 2>/dev/null || true)"
  if [[ "$CURRENT" != "3.12" ]]; then
    echo "Reemplazando entorno anterior Python $CURRENT por Python 3.12..."
    rm -rf "$VENV"
  fi
fi

if [[ ! -x "$VENV/bin/python" ]]; then
  echo "Creando entorno estable con Python 3.12..."
  "$UV_BIN" venv --python 3.12 "$VENV" || fail "No se pudo crear el entorno virtual."
fi

echo "Python: $($VENV/bin/python --version)"
echo "Verificando bibliotecas..."
"$UV_BIN" pip install --python "$VENV/bin/python" -r "$ROOT/requirements.txt" || fail "No se pudieron instalar las bibliotecas."

cd "$ROOT/app" || fail "No se encontró la carpeta app."
export STREAMLIT_SERVER_FILE_WATCHER_TYPE=none
export PYTHONUNBUFFERED=1

echo
echo "Abriendo el conciliador en el navegador..."
echo "Para cerrar la aplicación, cerrá esta ventana o presioná Control+C."
echo

"$VENV/bin/python" -m streamlit run main.py \
  --server.headless=false \
  --browser.gatherUsageStats=false \
  --server.address=localhost \
  --server.fileWatcherType=none
STATUS=$?
if [[ $STATUS -ne 0 ]]; then
  fail "La aplicación se cerró con código $STATUS."
fi
