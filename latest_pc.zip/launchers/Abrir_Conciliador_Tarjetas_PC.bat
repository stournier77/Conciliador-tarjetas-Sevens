@echo off
setlocal
set "ROOT=%~dp0.."
set "VENV=%ROOT%\runtime_pc\.venv"
if not exist "%ROOT%\runtime_pc" mkdir "%ROOT%\runtime_pc"
where py >nul 2>nul
if %errorlevel%==0 (
  set "PY=py -3"
) else (
  set "PY=python"
)
if not exist "%VENV%\Scripts\python.exe" %PY% -m venv "%VENV%"
"%VENV%\Scripts\python.exe" -m ensurepip --upgrade >nul 2>nul
"%VENV%\Scripts\python.exe" -m pip install --upgrade pip
"%VENV%\Scripts\python.exe" -m pip install -r "%ROOT%\requirements.txt"
cd /d "%ROOT%\app"
"%VENV%\Scripts\python.exe" -m streamlit run main.py --server.headless=true --browser.gatherUsageStats=false
endlocal
