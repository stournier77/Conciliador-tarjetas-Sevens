#!/bin/zsh
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP_DIR="$HOME/Documents/Conciliador Tarjetas Maveric"
DESKTOP="$HOME/Desktop"
mkdir -p "$APP_DIR"
rsync -a --delete --exclude 'runtime_mac' --exclude 'runtime_pc' "$ROOT/" "$APP_DIR/"
chmod +x "$APP_DIR/launchers/"*.command
ln -sf "$APP_DIR/launchers/Abrir_Conciliador_Tarjetas_Mac.command" "$DESKTOP/Conciliador de Tarjetas - Maveric.command"
"$APP_DIR/launchers/Abrir_Conciliador_Tarjetas_Mac.command"
