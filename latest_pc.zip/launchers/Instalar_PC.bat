@echo off
setlocal
set "ROOT=%~dp0.."
set "APP_DIR=%USERPROFILE%\Documents\Conciliador Tarjetas Maveric"
if not exist "%APP_DIR%" mkdir "%APP_DIR%"
xcopy "%ROOT%\*" "%APP_DIR%\" /E /I /Y >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "$W=New-Object -ComObject WScript.Shell; $S=$W.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Conciliador de Tarjetas - Maveric.lnk'); $S.TargetPath='%APP_DIR%\launchers\Abrir_Conciliador_Tarjetas_PC.bat'; $S.WorkingDirectory='%APP_DIR%'; $S.IconLocation='%APP_DIR%\assets\conciliador_tarjetas.ico'; $S.Save()"
call "%APP_DIR%\launchers\Abrir_Conciliador_Tarjetas_PC.bat"
endlocal
