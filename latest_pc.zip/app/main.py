from __future__ import annotations

import platform
import re
from datetime import datetime

import streamlit as st

from authorized_devices import authorization
from config import APP_DATE, APP_NAME, APP_VERSION
from engine import MavericFile, ReconciliationError, infer_maveric_group, reconcile
from updater import check_for_update

st.set_page_config(page_title=APP_NAME, page_icon="💳", layout="wide")

allowed, device_uuid, device = authorization()
if not allowed:
    st.error("Esta computadora no está habilitada para usar el conciliador.")
    st.code(device_uuid)
    st.caption("Enviá este ID al administrador para solicitar la habilitación.")
    st.stop()

st.title("💳 Conciliador de Tarjetas - Maveric")
st.caption("Brex vs Maveric · sin reutilizar boletos · búsqueda automática en archivos alternativos")

@st.cache_data(ttl=3600, show_spinner=False)
def _update_status():
    key = "mac" if platform.system() == "Darwin" else "windows"
    return check_for_update(key)

with st.sidebar:
    st.subheader("Equipo habilitado")
    st.write(f"**{device['name']}**")
    st.caption(device_uuid)
    st.subheader("Versión")
    st.write(f"**{APP_VERSION}** · {APP_DATE}")
    info = _update_status()
    if info.available:
        st.warning(f"Nueva versión disponible: {info.latest_version}")
        if info.release_url:
            st.link_button("Abrir actualización", info.release_url)
    else:
        st.caption(info.message)
    if st.button("Comprobar actualizaciones"):
        _update_status.clear()
        st.rerun()

st.subheader("1. Archivo Brex")
brex_file = st.file_uploader("Transactions de Brex", type=["xlsx"], accept_multiple_files=False)

st.subheader("2. Maveric principal")
primary_file = st.file_uploader("Archivo Maveric de la empresa que se está conciliando", type=["xls", "xlsx"], accept_multiple_files=False)
primary_group = "LEFITUR"
if primary_file:
    detected = infer_maveric_group(primary_file.name)
    options = ["LEFITUR", "DANARSIN", "PARAGUAY"]
    primary_group = st.selectbox(
        "Empresa principal",
        options=options,
        index=options.index(detected) if detected in options else 0,
    )

st.subheader("3. Maveric alternativos")
st.caption("Opcional. Cuando un cargo no aparece en la empresa principal, se buscará automáticamente aquí.")
alternate_files = st.file_uploader("Archivos Maveric DANARSIN / PARAGUAY / LEFITUR adicionales", type=["xls", "xlsx"], accept_multiple_files=True)
forced_groups: dict[str, str] = {}
for file in alternate_files or []:
    detected = infer_maveric_group(file.name)
    options = ["LEFITUR", "DANARSIN", "PARAGUAY"]
    forced_groups[file.name] = st.selectbox(
        f"Empresa de {file.name}", options=options,
        index=options.index(detected) if detected in options else 0,
        key=f"group_{file.name}",
    )

if st.button("Conciliar", type="primary", disabled=not (brex_file and primary_file)):
    try:
        with st.spinner("Leyendo archivos y conciliando..."):
            files = [MavericFile(primary_file.name, primary_file.getvalue(), primary_group)]
            files.extend(MavericFile(f.name, f.getvalue(), forced_groups[f.name]) for f in (alternate_files or []))
            result, stats = reconcile(brex_file.getvalue(), files, primary_group=primary_group)
        st.success("Conciliación terminada")
        cols = st.columns(min(4, max(1, len(stats))))
        for index, (name, value) in enumerate(sorted(stats.items())):
            cols[index % len(cols)].metric(name, value)

        now = datetime.now()
        source_name = re.sub(r"[^A-Za-z0-9_-]+", "_", primary_file.name.rsplit(".", 1)[0])[:45]
        filename = f"Conciliacion_Tarjetas_{primary_group}_{source_name}_{now:%Y-%m-%d_%H-%M-%S}.xlsx"
        st.download_button(
            "Descargar Excel conciliado",
            data=result,
            file_name=filename,
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
    except ReconciliationError as exc:
        st.error(str(exc))
    except Exception as exc:
        st.exception(exc)
