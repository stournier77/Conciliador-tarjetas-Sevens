#!/bin/zsh
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP_DIR="$HOME/Documents/Conciliador Tarjetas Maveric"
DESKTOP_APP="$HOME/Desktop/Conciliador de Tarjetas - Maveric.app"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

fail(){ echo; echo "ERROR: $1"; read "?Presioná Enter para cerrar..."; exit 1; }
mkdir -p "$APP_DIR"
rsync -a --delete --exclude runtime_mac --exclude runtime_pc "$ROOT/" "$APP_DIR/" || fail "No se pudo copiar la aplicación."
chmod +x "$APP_DIR/launchers/"*.command 2>/dev/null || true
xattr -dr com.apple.quarantine "$APP_DIR" 2>/dev/null || true

rm -rf "$DESKTOP_APP"
mkdir -p "$DESKTOP_APP/Contents/MacOS" "$DESKTOP_APP/Contents/Resources"
cat > "$DESKTOP_APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>Conciliador de Tarjetas - Maveric</string>
<key>CFBundleDisplayName</key><string>Conciliador de Tarjetas - Maveric</string>
<key>CFBundleIdentifier</key><string>uy.sevens.conciliador.tarjetas</string>
<key>CFBundleVersion</key><string>0.2.1</string>
<key>CFBundleShortVersionString</key><string>0.2.1</string>
<key>CFBundleExecutable</key><string>ConciliadorTarjetas</string>
<key>CFBundleIconFile</key><string>AppIcon</string>
<key>LSMinimumSystemVersion</key><string>11.0</string>
<key>NSHighResolutionCapable</key><true/>
</dict></plist>
PLIST
cat > "$DESKTOP_APP/Contents/MacOS/ConciliadorTarjetas" <<'START'
#!/bin/zsh
LAUNCHER="$HOME/Documents/Conciliador Tarjetas Maveric/launchers/Abrir_Conciliador_Tarjetas_Mac.command"
if [[ ! -f "$LAUNCHER" ]]; then
 osascript -e 'display alert "Conciliador no instalado" message "Ejecutá nuevamente el instalador." as critical'
 exit 1
fi
chmod +x "$LAUNCHER" 2>/dev/null || true
/usr/bin/osascript <<OSA
 tell application "Terminal"
   activate
   do script quoted form of "$LAUNCHER"
 end tell
OSA
START
chmod +x "$DESKTOP_APP/Contents/MacOS/ConciliadorTarjetas"
ICON_PNG="$APP_DIR/assets/conciliador_tarjetas.png"
ICONSET="$TMP_DIR/AppIcon.iconset"; mkdir -p "$ICONSET"
for spec in "16 icon_16x16.png" "32 icon_16x16@2x.png" "32 icon_32x32.png" "64 icon_32x32@2x.png" "128 icon_128x128.png" "256 icon_128x128@2x.png" "256 icon_256x256.png" "512 icon_256x256@2x.png" "512 icon_512x512.png" "1024 icon_512x512@2x.png"; do
 SIZE="${spec%% *}"; NAME="${spec#* }"; sips -z "$SIZE" "$SIZE" "$ICON_PNG" --out "$ICONSET/$NAME" >/dev/null || fail "No se pudo crear el ícono."
done
iconutil -c icns "$ICONSET" -o "$DESKTOP_APP/Contents/Resources/AppIcon.icns" || fail "No se pudo integrar el ícono."
xattr -dr com.apple.quarantine "$DESKTOP_APP" 2>/dev/null || true
touch "$DESKTOP_APP"; killall Finder >/dev/null 2>&1 || true
open "$DESKTOP_APP"
echo; echo "Instalación finalizada."
read "?Presioná Enter para cerrar..."
