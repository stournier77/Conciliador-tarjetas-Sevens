from __future__ import annotations

import re
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

import streamlit as st

from authorized_devices import authorization
from config import APP_DATE, APP_NAME, APP_VERSION, INSTALL_FOLDER_NAME, OUTPUT_FOLDER_NAME
from engine import MavericFile, ReconciliationError, infer_maveric_group, read_brex, reconcile

st.set_page_config(page_title=APP_NAME, page_icon="💳", layout="wide")

allowed, device_uuid, device = authorization()
if not allowed:
    st.error("Esta computadora no está habilitada para usar el conciliador.")
    st.code(device_uuid)
    st.caption("Enviá este ID al administrador para solicitar la habilitación.")
    st.stop()

st.title("💳 Conciliador de Tarjetas - Maveric")
st.caption("Brex vs Maveric · agrupación por tarjeta, fecha y autorización · cada boleto se usa una sola vez")

with st.sidebar:
    st.subheader("Equipo habilitado")
    st.write(f"**{device['name']}**")
    st.caption(device_uuid)
    st.subheader("Versión")
    st.write(f"**{APP_VERSION}** · {APP_DATE}")
    st.caption("La actualización se comprueba automáticamente antes de abrir la app.")

st.subheader("1. Archivo Brex")
brex_file = st.file_uploader("Transactions de Brex", type=["xlsx"], accept_multiple_files=False)

st.subheader("2. Archivo Maveric")
maveric_file = st.file_uploader("Archivo Maveric de la empresa que se está conciliando", type=["xls", "xlsx"], accept_multiple_files=False)

primary_group = "LEFITUR"
if maveric_file:
    detected = infer_maveric_group(maveric_file.name)
    options = ["LEFITUR", "DANARSIN", "PARAGUAY"]
    primary_group = st.selectbox(
        "Empresa del archivo Maveric",
        options=options,
        index=options.index(detected) if detected in options else 0,
    )


def _period_label(start, end) -> str:
    return f"{start:%d-%m-%Y}_al_{end:%d-%m-%Y}"


def _spanish_saved_label(now: datetime) -> str:
    months = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]
    return f"{now.day}-{months[now.month-1]}-{now.year}_{now:%H-%M}hs"


def _open_output_folder() -> None:
    folder = Path.home() / "Documents" / INSTALL_FOLDER_NAME / OUTPUT_FOLDER_NAME
    folder.mkdir(parents=True, exist_ok=True)
    if sys.platform == "darwin":
        subprocess.Popen(["open", str(folder)])
    elif os.name == "nt":
        os.startfile(str(folder))  # type: ignore[attr-defined]
    else:
        subprocess.Popen(["xdg-open", str(folder)])


left_action, right_action = st.columns([1, 1])
with left_action:
    conciliar = st.button("Conciliar", type="primary", disabled=not (brex_file and maveric_file), use_container_width=True)
with right_action:
    if st.button("ABRIR CARPETA DE CONCILIACIÓN", use_container_width=True):
        try:
            _open_output_folder()
        except Exception as exc:
            st.error(f"No se pudo abrir la carpeta: {exc}")


if conciliar:
    try:
        brex_bytes = brex_file.getvalue()
        with st.spinner("Leyendo archivos y conciliando..."):
            brex_df = read_brex(brex_bytes)
            if brex_df.empty:
                raise ReconciliationError("El archivo Brex no contiene transacciones válidas")
            start_date = min(brex_df["_date"])
            end_date = max(brex_df["_date"])
            result, stats = reconcile(
                brex_bytes,
                [MavericFile(maveric_file.name, maveric_file.getvalue(), primary_group)],
                primary_group=primary_group,
            )

        now = datetime.now()
        period = _period_label(start_date, end_date)
        filename = f"Conciliacion_Brex_{period}_guardado_{_spanish_saved_label(now)}.xlsx"
        base = Path.home() / "Documents" / INSTALL_FOLDER_NAME / OUTPUT_FOLDER_NAME / period
        base.mkdir(parents=True, exist_ok=True)
        output_path = base / filename
        output_path.write_bytes(result)

        st.success("Conciliación terminada y guardada automáticamente")
        st.code(str(output_path))
        cols = st.columns(min(4, max(1, len(stats))))
        for index, (name, value) in enumerate(sorted(stats.items())):
            cols[index % len(cols)].metric(name, value)

        st.download_button(
            "Descargar también una copia",
            data=result,
            file_name=filename,
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
    except ReconciliationError as exc:
        st.error(str(exc))
    except Exception as exc:
        st.exception(exc)
