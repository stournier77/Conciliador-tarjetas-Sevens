#!/bin/zsh
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VENV="$ROOT/runtime_mac/.venv"
PYTHON_BIN="/usr/bin/python3"

mkdir -p "$ROOT/runtime_mac"
if [ ! -x "$VENV/bin/python" ]; then
  "$PYTHON_BIN" -m venv "$VENV"
fi
"$VENV/bin/python" -m ensurepip --upgrade >/dev/null 2>&1 || true
"$VENV/bin/python" -m pip install --upgrade pip >/dev/null
"$VENV/bin/python" -m pip install -r "$ROOT/requirements.txt"
cd "$ROOT/app"
exec "$VENV/bin/python" -m streamlit run main.py --server.headless=true --browser.gatherUsageStats=false
