@echo off
setlocal EnableExtensions
set "ROOT=%~dp0.."
set "RUNTIME=%ROOT%\runtime_pc"
set "UV_DIR=%RUNTIME%\uv"
set "UV_BIN=%UV_DIR%\uv.exe"
set "VENV=%RUNTIME%\.venv"
if not exist "%RUNTIME%" mkdir "%RUNTIME%"

if not exist "%UV_BIN%" (
  echo Instalando motor aislado de Python...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$env:UV_INSTALL_DIR='%UV_DIR%'; irm https://astral.sh/uv/install.ps1 | iex"
  if errorlevel 1 goto :error
)

"%UV_BIN%" python install 3.12
if errorlevel 1 goto :error

if exist "%VENV%\Scripts\python.exe" (
  for /f %%V in ('"%VENV%\Scripts\python.exe" -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"') do set "PYVER=%%V"
  if not "%PYVER%"=="3.12" rmdir /s /q "%VENV%"
)

if not exist "%VENV%\Scripts\python.exe" (
  "%UV_BIN%" venv --python 3.12 "%VENV%"
  if errorlevel 1 goto :error
)

"%UV_BIN%" pip install --python "%VENV%\Scripts\python.exe" -r "%ROOT%\requirements.txt"
if errorlevel 1 goto :error

set "STREAMLIT_SERVER_FILE_WATCHER_TYPE=none"
cd /d "%ROOT%\app"
"%VENV%\Scripts\python.exe" -m streamlit run main.py --server.headless=false --browser.gatherUsageStats=false --server.address=localhost --server.fileWatcherType=none
if errorlevel 1 goto :error
exit /b 0

:error
echo.
echo ERROR: No se pudo iniciar el Conciliador de Tarjetas.
echo.
pause
exit /b 1
