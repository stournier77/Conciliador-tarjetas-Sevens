# Conciliador Tarjetas Maveric Sevens 0.3.5

Arranque local en http://127.0.0.1:8783. Mantiene el motor de conciliación de 0.3.4 sin cambios.

Descomprimir latest_mac.zip o latest_pc.zip en una carpeta temporal y ejecutar Instalar_Conciliador_Tarjetas_Sevens_Mac.command o Instalar_Conciliador_Tarjetas_Sevens_PC.bat. No extraer directamente sobre la instalación anterior.

La instalación conserva Documents/App Conciliador Tarjetas Maveric/Archivos APP y Conciliaciones Tarjetas Maveric. Respalda el programa en Archivos APP/backups y no elimina históricos, logs, runtimes ni archivos adicionales. Los históricos de la ruta antigua se copian una vez a Historicos_instalacion_anterior, sin sobrescribir originales.

Accesos en la carpeta principal/Accesos: Abrir Conciliador, Editar proyecto, Publicar GitHub. El acceso de edición abre el código; se puede abrir esa carpeta en Codex o en el editor preferido. Publicar genera Publicacion GitHub con latest_mac.zip, latest_pc.zip y version.txt y abre la página de creación de Release. Revisar y subir esos tres archivos con tag v0.3.5. La publicación final se realiza manualmente.

GitHub comprueba Releases al arrancar; sin conexión continúa con la versión instalada. Valida rutas, estructura, versión y checksum cuando GitHub lo proporciona. Sustituye únicamente archivos del programa y revierte si falla la copia. Una actualización se ejecuta con el código nuevo. La comprobación de importaciones dura hasta 25 segundos; una falla reconstruye únicamente .venv, conservando el entorno anterior. Creación e instalación tienen límite de 600 segundos cada una. No reinstala bibliotecas en cada inicio si la comprobación y la huella de requirements coinciden. Se espera hasta 60 segundos a Streamlit antes de abrir el navegador. El bloqueo evita dos arranques simultáneos; si 8783 está ocupado por otro proceso informa el problema y no cambia de puerto.

Diagnóstico: logs/ultimo_arranque_mac.log o ultimo_arranque_pc.log, y streamlit_mac.log o streamlit_pc.log. Cerrar la terminal o Control+C detiene el servidor. Si el bloqueo quedó de una ejecución ya terminada, el sistema lo libera automáticamente.

Antes de migrar: cerrar la app, copiar toda la carpeta App Conciliador Tarjetas Maveric a un respaldo externo y comprobar los históricos. Después: abrir el acceso, comprobar URL 8783 y una conciliación conocida. Para volver atrás cerrar la app y restaurar los archivos del programa desde Archivos APP/backups; no restaurar ni borrar históricos. Si requirements cambió se reconstruirá el entorno.

No ejecutar los instaladores viejos: usaban rsync --delete, robocopy /MIR y eliminación de otras carpetas. No reemplazar la carpeta principal completa.

Terminal Mac: las antiguas líneas que cargan runtime_mac/uv/env no son necesarias. Quitar solamente esas referencias de .bash_profile y .zshrc, haciendo una copia antes. uv se instala con UV_NO_MODIFY_PATH=1.

Pruebas: python tests/test_startup.py; tests/test_engine.py conserva sus pruebas del motor. Windows requiere verificación en un equipo Windows; las pruebas realizadas en Mac no sustituyen esa verificación. Primera instalación/reparación requiere internet y Python administrado por uv.

El repositorio usa tres archivos binarios. Para editar, descomprimir el paquete y trabajar en Archivos APP; incrementar version.txt y app/config.py antes de generar una nueva distribución. No subir históricos, runtimes, logs o respaldos.
