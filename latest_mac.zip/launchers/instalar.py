import os
from pathlib import Path
import shutil
import subprocess
import sys
from arranque import ROOT, deploy

def install():
    # La aplicación actual guarda en esta ruta; mantenerla también en Windows.
    target = Path.home() / 'Documents' / 'App Conciliador Tarjetas Maveric'
    files = target / 'Archivos APP'
    output = target / 'Conciliaciones Tarjetas Maveric'
    output.mkdir(parents=True, exist_ok=True)
    deploy(ROOT, files)
    old = Path.home() / 'Documents' / 'Conciliador Tarjetas Maveric' / output.name
    if old.exists():
        # Copia completa en subcarpeta separada para conservar colisiones.
        imported = output / 'Historicos_instalacion_anterior'
        if not imported.exists(): shutil.copytree(old, imported)
    shortcuts = target / 'Accesos'
    shortcuts.mkdir(exist_ok=True)
    if os.name == 'nt':
        (shortcuts / 'Abrir Conciliador.bat').write_text('@echo off\r\ncall "%~dp0..\\Archivos APP\\launchers\\Abrir_Conciliador_Tarjetas_PC.bat"\r\n')
        (shortcuts / 'Editar proyecto.bat').write_text('@echo off\r\nstart "" "%~dp0..\\Archivos APP"\r\n')
        (shortcuts / 'Publicar GitHub.bat').write_text('@echo off\r\ncall "%~dp0..\\Archivos APP\\launchers\\Preparar_publicacion_PC.bat"\r\n')
    else:
        actions = {
            'Abrir Conciliador.command': 'exec "$BASE/Archivos APP/launchers/Abrir_Conciliador_Tarjetas_Mac.command"',
            'Editar proyecto.command': 'open "$BASE/Archivos APP"; open "https://github.com/stournier77/Conciliador-tarjetas-Sevens"',
            'Publicar GitHub.command': 'exec "$BASE/Archivos APP/launchers/Preparar_publicacion_Mac.command"',
        }
        for name, command in actions.items():
            f = shortcuts / name
            f.write_text('#!/bin/zsh\nBASE="$(cd "$(dirname "$0")/.." && pwd)"\n' + command + '\n')
            f.chmod(0o755)
    print('Instalación completa:', target)
    print('Accesos para abrir, editar y publicar:', shortcuts)
    print('Los archivos y carpetas ajenos al programa no se eliminaron.')

if __name__ == '__main__': install()
