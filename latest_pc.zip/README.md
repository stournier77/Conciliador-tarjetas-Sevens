# Conciliador de Tarjetas - Maveric

Versión 0.2.0.

## Lógica principal

- Lee únicamente movimientos Maveric con tarjeta CC y autorización.
- Agrupa los boletos por archivo, fecha Maveric, tarjeta, autorización y compañía.
- Dentro de una misma autorización busca subconjuntos exactos de uno o más boletos.
- Prioridad: agrupado misma fecha, individual misma fecha, agrupado otra fecha, individual otra fecha.
- Ningún boleto Maveric puede utilizarse en dos cargos Brex.
- Cuando el cargo no aparece en la empresa principal, revisa los archivos alternativos cargados y marca `PERTENECE A DANARSIN`, `PERTENECE A PARAGUAY` o `PERTENECE A LEFITUR`.
- Mantiene la lógica de AGENT FEE y proveedor CTC.

## Archivos de GitHub Release

Subir exactamente:

- `latest_mac.zip`
- `latest_pc.zip`
- `version.txt`

Antes de publicar, editar `github_repo.txt` con `usuario/repositorio`.

## Instalación inicial

### Mac

1. Poner `Instalar_Conciliador_Tarjetas_Mac.command` y `latest_mac.zip` en la misma carpeta.
2. Clic derecho en el instalador, elegir **Abrir**.
3. El instalador copia la app a Documentos, crea el entorno e instala bibliotecas.

### Windows

1. Poner `Instalar_Conciliador_Tarjetas_PC.bat` y `latest_pc.zip` en la misma carpeta.
2. Doble clic en el instalador.
3. El instalador copia la app a Documentos, crea el entorno e instala bibliotecas.

## Equipos autorizados

Usa los mismos UUID del Conciliador IATA.
